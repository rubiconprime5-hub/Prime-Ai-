# PRIME AI Android starter

This is a small starter Android project for the PRIME AI assistant.

## Included in version 0.1
- Basic PRIME AI screen
- Text-to-speech test button
- Flashlight toggle button
- GitHub Actions workflow that builds a debug APK in the cloud

## Not included yet
- "Hey Prime" wake-word detection
- Offline speech recognition
- Background microphone service
- Natural-language command handling
- Online AI connection

Those features need to be added and tested in later versions. Android may require a visible foreground-service notification for ongoing microphone use.

## Build
Push these files to the `main` branch of your GitHub repository. Open the **Actions** tab, select **Build PRIME AI APK**, and run the workflow if it has not started automatically. When it finishes, download the `PRIME-AI-debug-APK` artifact.

This is a development/debug APK, not a Play Store release.
