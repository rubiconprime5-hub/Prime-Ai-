package com.primeai.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.hardware.camera2.CameraManager;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextToSpeech tts;
    private CameraManager cameraManager;
    private String cameraId;
    private boolean torchOn = false;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        cameraManager = (CameraManager)getSystemService(Context.CAMERA_SERVICE);
        try {
            for (String id : cameraManager.getCameraIdList()) {
                if (cameraManager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) != null &&
                    Boolean.TRUE.equals(cameraManager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE))) {
                    cameraId = id; break;
                }
            }
        } catch (Exception ignored) {}

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault());
        });

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);
        layout.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("PRIME AI");
        title.setTextSize(32);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        status = new TextView(this);
        status.setText("Your assistant is ready. Version 0.1");
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, 28, 0, 28);
        layout.addView(status, sp);

        Button speak = new Button(this);
        speak.setText("Test voice");
        speak.setOnClickListener(v -> {
            status.setText("PRIME AI is here.");
            if (tts != null) tts.speak("Hello. PRIME AI is here.", TextToSpeech.QUEUE_FLUSH, null, "prime_intro");
        });
        layout.addView(speak);

        Button torch = new Button(this);
        torch.setText("Toggle flashlight");
        torch.setOnClickListener(v -> toggleTorch());
        layout.addView(torch);

        TextView note = new TextView(this);
        note.setText("Starter build only. Wake phrase, offline voice recognition and advanced phone controls are not included yet.");
        note.setTextColor(0xFFB8C5D1);
        note.setTextSize(14);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, 24, 0, 0);
        layout.addView(note, np);

        setContentView(layout);
    }

    private void toggleTorch() {
        if (cameraId == null) {
            status.setText("No flashlight was detected on this phone.");
            return;
        }
        try {
            torchOn = !torchOn;
            cameraManager.setTorchMode(cameraId, torchOn);
            status.setText(torchOn ? "Flashlight is ON" : "Flashlight is OFF");
            if (tts != null) tts.speak(torchOn ? "Flashlight on" : "Flashlight off", TextToSpeech.QUEUE_FLUSH, null, "torch");
        } catch (Exception e) {
            status.setText("Could not control the flashlight. Check camera permission or device support.");
            torchOn = false;
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        try { if (torchOn && cameraId != null) cameraManager.setTorchMode(cameraId, false); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
